function deptCheck() {
	const deptno = document.frm.deptno.value.trim()
	const dname = document.frm.deptno.dname.trim()
	const loc = document.frm.loc.value.trim()
	if (deptno.length == 0) {
		alert("부서 번호를 입력하세요.");
		return false;
	}
	if (dname.lenght == 0) {
		alert("부서 이름을 입력하세요.");
		return false;
	}
	if (loc.length == 0) {
		alert("부서 위치을 입력하세요.");
		return false;
	}
	return true;
}

function open_win(url, name) {
	window.open(url, name, "width=500, height=230");
}
