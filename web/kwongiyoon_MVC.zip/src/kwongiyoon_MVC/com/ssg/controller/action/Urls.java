package kwongiyoon_MVC.com.ssg.controller.action;

public enum Urls {
	
	DEPT_LIST("/dept/deptList.jsp"),
	DEPT_WRITE("/dept/deptWrite.jsp"),
	DEPT_WRITE_FORM("/dept/deptWriteForm.jsp"),
	DEPT_VIEW("/dept/deptView.jsp"),
	DEPT_UPDATE("/dept/deptUpdate.jsp"),
	DEPT_UPDATE_FORM("/dept/deptUpdateForm.jsp"),
	DEPT_DELETE("/dept/deptDelete.jsp");

	final private String url; 
	private Urls(String url) {
		this.url = url;
	}
	public String getUrl() { 
		return this.url; 
	} 
}
