package kwongiyoon_MVC.com.ssg.controller.action;

import kwongiyoon_MVC.com.ssg.service.DeptService;
import kwongiyoon_MVC.com.ssg.service.iDeptService;

public class DeptAction {
	protected iDeptService deptService = DeptService.getDeptService();
}
