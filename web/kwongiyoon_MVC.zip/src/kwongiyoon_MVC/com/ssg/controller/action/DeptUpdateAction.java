package kwongiyoon_MVC.com.ssg.controller.action;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kwongiyoon_MVC.com.ssg.dto.DeptDto;

public class DeptUpdateAction extends DeptAction implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int deptno = Integer.parseInt(request.getParameter("deptno"));
		String dname = request.getParameter("dname");
		String loc = request.getParameter("loc");
		
		DeptDto deptDto = new DeptDto(deptno, dname, loc);
		super.deptService.updateDept(deptDto);
		
		new DeptListAction().execute(request, response);
	}

}
