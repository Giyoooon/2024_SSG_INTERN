package kwongiyoon_MVC.com.ssg.controller.action;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class DeptDeleteAction extends DeptAction implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int deptno = Integer.parseInt(request.getParameter("deptno"));
		super.deptService.deleteDept(deptno);
		new DeptListAction().execute(request, response);
	}

}
