package kwongiyoon_MVC.com.ssg.controller.action;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kwongiyoon_MVC.com.ssg.dto.DeptDto;

public class DeptViewAction extends DeptAction implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url = Urls.DEPT_VIEW.getUrl();
		int deptno = Integer.parseInt(request.getParameter("deptno"));
		
		DeptDto deptDto = super.deptService.selectOneDept(deptno);
		request.setAttribute("dept", deptDto);
		RequestDispatcher dispatcher = request.getRequestDispatcher(url);
		dispatcher.forward(request, response);
	}

}
