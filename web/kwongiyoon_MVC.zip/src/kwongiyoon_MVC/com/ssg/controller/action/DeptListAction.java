package kwongiyoon_MVC.com.ssg.controller.action;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kwongiyoon_MVC.com.ssg.dto.DeptDto;

public class DeptListAction extends DeptAction implements Action {
	/**
	 * 1. Dept table의 모든 정보를 list 형식으로 가져온다.
	 */
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url = Urls.DEPT_LIST.getUrl();
		List<DeptDto> deptDtoList = super.deptService.selectAllDept();
		request.setAttribute("deptList", deptDtoList);
		RequestDispatcher dispatcher = request.getRequestDispatcher(url);
		dispatcher.forward(request, response);
	}

}
