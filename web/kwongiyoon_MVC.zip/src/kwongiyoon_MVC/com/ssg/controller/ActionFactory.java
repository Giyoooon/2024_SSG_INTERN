package kwongiyoon_MVC.com.ssg.controller;

import kwongiyoon_MVC.com.ssg.controller.action.Action;
import kwongiyoon_MVC.com.ssg.controller.action.DeptDeleteAction;
import kwongiyoon_MVC.com.ssg.controller.action.DeptListAction;
import kwongiyoon_MVC.com.ssg.controller.action.DeptUpdateAction;
import kwongiyoon_MVC.com.ssg.controller.action.DeptUpdateFormAction;
import kwongiyoon_MVC.com.ssg.controller.action.DeptViewAction;
import kwongiyoon_MVC.com.ssg.controller.action.DeptWriteAction;
import kwongiyoon_MVC.com.ssg.controller.action.DeptWriteFormAction;

public class ActionFactory {
	private static ActionFactory instance = new ActionFactory();

	private ActionFactory() {
		super();
	}

	public static ActionFactory getInstance() {
		return instance;
	}

	public Action getAction(String command) {
		Action action = null;
		System.out.println("ActionFactory :" + command);
		/* 추가된 부분 */
		if (command.equals("dept_list")) {
			action = new DeptListAction();
		} else if (command.equals("dept_write_form")) {
			action = new DeptWriteFormAction();
		} else if (command.equals("dept_write")) {
			action = new DeptWriteAction();
		} else if (command.equals("dept_view")) {
			action = new DeptViewAction();
		} else if (command.equals("dept_update_form")) {
			action = new DeptUpdateFormAction();
		} else if (command.equals("dept_update")) {
			action = new DeptUpdateAction();
		} else if (command.equals("dept_delete")) {
			action = new DeptDeleteAction();
		}
		return action;
	}
}
