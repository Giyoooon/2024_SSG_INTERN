package kwongiyoon_MVC.com.ssg.service;

import java.util.List;

import kwongiyoon_MVC.com.ssg.dao.DeptDao;
import kwongiyoon_MVC.com.ssg.dao.iDeptDao;
import kwongiyoon_MVC.com.ssg.dto.DeptDto;

public class DeptService implements iDeptService{
	private static DeptService instance = new DeptService();
	
	private DeptService() {}
	
	public static DeptService getDeptService() {
		return instance;
	}
	
	private iDeptDao deptDao = DeptDao.getDeptDao();
	
	@Override
	public List<DeptDto> selectAllDept() {
		return deptDao.selectAllDept();
	}

	@Override
	public DeptDto selectOneDept(int deptno) {
		return deptDao.selectOneDept(deptno);
	}

	@Override
	public void insertDept(DeptDto deptDto) {
		deptDao.insertDept(deptDto);
	}

	@Override
	public void updateDept(DeptDto deptDto) {
		deptDao.updateDept(deptDto);
	}

	@Override
	public void deleteDept(int deptno) {
		deptDao.deleteDept(deptno);
	}

}
