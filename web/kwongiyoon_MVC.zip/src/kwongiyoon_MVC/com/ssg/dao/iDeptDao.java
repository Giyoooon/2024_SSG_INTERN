package kwongiyoon_MVC.com.ssg.dao;

import java.util.List;

import kwongiyoon_MVC.com.ssg.dto.DeptDto;

public interface iDeptDao {
	// 1. select all
	List<DeptDto> selectAllDept();
	
	// 2. select one
	DeptDto selectOneDept(int deptno);
	
	// 3. insert 
	void insertDept(DeptDto deptDto);
	
	// 4. update
	void updateDept(DeptDto deptDto);
	
	// 5. delete
	void deleteDept(int deptno);
}
