package kwongiyoon_MVC.com.ssg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import kwongiyoon_MVC.com.ssg.dto.DeptDto;
import kwongiyoon_MVC.com.ssg.util.DBManager;

public class DeptDao implements iDeptDao{
	private static DeptDao instance = new DeptDao();
	
	private DeptDao() {}
	
	public static DeptDao getDeptDao() {
		return instance;
	}

	@Override
	public List<DeptDto> selectAllDept() {
		List<DeptDto> deptList = new ArrayList<DeptDto>();
		String sql = "select * from dept";
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			conn = DBManager.getConnection();
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			while(rs.next()) {
				int deptno = rs.getInt("deptno");
				String dname = rs.getString("dname");
				String loc = rs.getString("loc");
				deptList.add(new DeptDto(deptno, dname, loc));
			}
		} catch(SQLException sqle) {
			sqle.printStackTrace();
		} finally {
			DBManager.close(conn, stmt, rs);
		}
		return deptList;
	}

	@Override
	public DeptDto selectOneDept(int deptno) {
		DeptDto deptDto = new DeptDto();
		String sql = "select * from dept where deptno = ?";
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, deptno);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				deptDto.setDeptno(rs.getInt("deptno"));
				deptDto.setDname(rs.getString("dname"));
				deptDto.setLoc(rs.getString("loc"));
			}
		} catch(SQLException sqle) {
			sqle.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt, rs);
		}
		
		return deptDto;
	}

	@Override
	public void insertDept(DeptDto deptDto) {
		
	}

	@Override
	public void updateDept(DeptDto deptDto) {
		
	}

	@Override
	public void deleteDept(int deptno) {
		
	}
	
	
}
