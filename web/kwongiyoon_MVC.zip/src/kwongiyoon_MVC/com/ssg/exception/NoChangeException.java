package kwongiyoon_MVC.com.ssg.exception;

public class NoChangeException extends Exception {

}
