package kwongiyoon_MVC.com.ssg.exception;

public interface ExceptionHandling {
	String errorMsg(String msg);
}
